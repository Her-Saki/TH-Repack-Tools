#include <string>
#include <tuple>
#include <unordered_map>

std::unordered_map<uint8_t, std::tuple<std::string, uint8_t>> opcodes = {
	{0x00, std::make_tuple("EndBlock", 0)},
	{0x01, std::make_tuple("SpecialEffect", 2)},
	{0x03, std::make_tuple("Nazo03", 2)},
	{0x04, std::make_tuple("Jump", 2)},
	{0x05, std::make_tuple("Choice", -1)},
	{0x07, std::make_tuple("PreviousChoicePosition", 0)},
	{0x0a, std::make_tuple("LoadBG", 8)},
	{0x14, std::make_tuple("ClearBG", 1)},
	{0x20, std::make_tuple("End20", 0)},
	{0x28, std::make_tuple("ChoiceData", 0)},
	{0x30, std::make_tuple("Nazo30", 1)},
	{0x3d, std::make_tuple("IfFlagsEqualJump", 3)},
	{0x42, std::make_tuple("DisplayBG", 6)},
	{0x43, std::make_tuple("ChangeCharacter", 3)},
	{0x4d, std::make_tuple("BGM", 0)},
	{0x50, std::make_tuple("PCM", 0)},
	{0x54, std::make_tuple("DisplayMessage", 1)},
	{0x58, std::make_tuple("SetTextOffset", 1)},
	{0x64, std::make_tuple("Nazo64", 0)},
	{0x66, std::make_tuple("FadeOut", 0)},
	{0x6C, std::make_tuple("LoadPCM", 2)},
	{0x6E, std::make_tuple("PlayBGM", 2)},
	{0x73, std::make_tuple("SetTextSpeed", 1)},
	{0x77, std::make_tuple("BGMFadeWait", 0)},
    {0xf2, std::make_tuple("SayNameF2", 0)}};
